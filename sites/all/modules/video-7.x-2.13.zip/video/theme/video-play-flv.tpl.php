<?php
/**
 * @file
 * Theme file to handle flv output.
 *
 * Variables passed.
 * $item is the video object.
 * $themed_output is the rendered html.
 */
print $themed_output;
